import Com.Algorithm365.DataStructures.*;

public class LibMang{
    

}