package Com.Algorithm365.App;

import Com.Algorithm365.DataStructures.MyList;

public class App {

    public static void main(String[] args) {
        // Creation of new Object for Mylist Class
        MyList mylist = new MyList();
        mylist.addElement(5);
        mylist.addElement(7);
        mylist.PrintElments();
    }
    
}
